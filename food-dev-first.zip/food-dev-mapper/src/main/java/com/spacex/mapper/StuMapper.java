package com.spacex.mapper;

import com.spacex.my.mapper.MyMapper;
import com.spacex.pojo.Stu;

public interface StuMapper extends MyMapper<Stu> {
}