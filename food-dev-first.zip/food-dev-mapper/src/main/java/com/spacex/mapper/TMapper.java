package com.spacex.mapper;

import com.spacex.my.mapper.MyMapper;
import com.spacex.pojo.T;

public interface TMapper extends MyMapper<T> {
}