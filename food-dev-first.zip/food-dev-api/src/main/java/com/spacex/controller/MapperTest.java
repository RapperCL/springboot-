package com.spacex.controller;

import com.spacex.service.StuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MapperTest {


    @Autowired
    private StuService stuService;

      @GetMapping("/Stu")
    public Object getStu(int id){
          return stuService.StuInfo(id);
      }



}
